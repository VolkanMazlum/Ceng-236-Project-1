

function [new_pic] = bilinear(I, dimension)

    w = size(I,1);
    h = size(I,2);
    o_row = dimension(1);
    o_col = dimension(2);

     
    new_R = w / o_row;                %to find how much larger image will be

    new_C = h / o_col;


    [col, row] = meshgrid(1 : o_col, 1 : o_row);

    row = row * new_R;
    col = col * new_C;

    r = floor(row);                       %to not get float, to get integer
    c = floor(col);
    

    r(r < 1) = 1;
    c(c < 1) = 1;
    r(r > w - 1) = w - 1;                 %to describe, end-of-line and start-of-line
    c(c > h - 1) = h - 1;


    R = row - r;
    C = col - c;


    dim1 = sub2ind([w, h], r, c);            %to get distance from each edges
    dim2 = sub2ind([w, h], r+1,c);
    dim3 = sub2ind([w, h], r, c+1);
    dim4 = sub2ind([w, h], r+1, c+1);       

    new_pic = zeros(o_row, o_col);        %to fill zero
    new_pic = cast(new_pic, class(I));

    temp = I(dim1).*(1 - R).*(1 - C) + ...                  %to calculate for each edges, top, left, right, bottom
               I(dim2).*(R).*(1 - C) + ...
                   I(dim3).*(1 - R).*(C) + ...
                      I(dim4).*(R).*(C);
    new_pic = cast(temp, class(I));
endfunction
