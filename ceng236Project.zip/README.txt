It is my project of Ceng-236. I want to explain some parts of the project. 
I used a photo of an apple, which I added into zip.

There are 4 methods:
1- Linear interpolation: If you want to run that, first you need to open odev.m and after that, it can be worked.

2- Divided Difference: I used this formula that: f2-f1/M + f1, M is how much larger we make upsampling our image, 
f2 and f1 are the pixels we have from the unchanged picture.

3- Linear via Bisection method: I take the average pixels I have from the unchanged pictures.

4- Nearest Neighbor: I also searched this method on the web, so that it is used for image processing 
and I wanted to try to use that. It is additional for my project.

I prefer to use linear and divided, almost linear. I also did some exercises about cubic spline,
but I didn't add. Normally, the cubic spline is the best interpolation in my opinion. 

