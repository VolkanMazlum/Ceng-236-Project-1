%---------Linear METHOD--------------

I = imread('C:\\Users\\VOLKAN MAZLUM\\Desktop\\elma.png','png');

out(:,:,1) = bilinear(I(:,:,1), [640 480]);
out(:,:,2) = bilinear(I(:,:,2), [640 480]);
out(:,:,3) = bilinear(I(:,:,3), [640 480]);


figure;
imshow(I);
figure;
imshow(out);
%imwrite(K,'C:\\Users\\VOLKAN MAZLUM\\Desktop\\elma.png');   %it is for writing imgae into image


