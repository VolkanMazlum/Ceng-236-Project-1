% NEAREST NEIGHBOR METHOD


I = imread('C:\\Users\\VOLKAN MAZLUM\\Desktop\\elma.png','png');


figure;
imshow(I);

[w, h, d ]= size(I);



M = 2;   %it is a size how much upsampling we want to do


R = zeros([size(I,1)*M size(I,2)*M ]);
G = zeros([size(I,1)*M size(I,2)*M ]);
B = zeros([size(I,1)*M size(I,2)*M ]);

K = zeros([size(I,1)*M size(I,2)*M ]);   %boyutlarini iki katina cikartiyoruz, hem boyunu hem enini
m = 1;
n = 1;

for i = 1:w                       %aralarini sifir ile doldurdum, 2 katina denk gelecek sekilde
   for j = 1:h
     K(m,n) = I(i,j);
     n = n + M ;
   endfor
   m = m + M ;
   n = 1;
endfor
m = 1;
n = 1;

for i = 1:w                       %aralarini sifir ile doldurdum, 2 katina denk gelecek sekilde
   for j = 1:h
     R(m,n) = I(i,j,1);
     G(m,n) = I(i,j,2);
     B(m,n) = I(i,j,3);
     n = n + M ;
   endfor
   m = m + M ;
   n = 1;
endfor

for i = 1:M:size(K,1)-M
    for j = 1:M:size(K,2)-M
      
      
      for ind_i = i:i+M
        for ind_j = j : j+M
           if(R(ind_i,ind_j) == 0 )
              R(ind_i,ind_j) =  R(i,j);
          endif
          if(G(ind_i,ind_j) == 0 )
              G(ind_i,ind_j) =  G(i,j);
          endif
          if(B(ind_i,ind_j) == 0 )
              B(ind_i,ind_j) =  B(i,j);
          endif
        endfor
        
      endfor
     
      
    end
 end

K(:,:,1) = R ;
K(:,:,2) = G ;
K(:,:,3) = B ;

K = uint8(K);

figure,imagesc(K);

%imwrite(K,'C:\\Users\\VOLKAN MAZLUM\\Desktop\\elma.png');   %it is for writing imgae into image