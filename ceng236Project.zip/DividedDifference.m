% DIVIDED DIFFERENCE INTERPOLATION METHOD

I = imread('C:\\Users\\VOLKAN MAZLUM\\Desktop\\elma.png','png');


figure;
imshow(I);

[w, h, d ]= size(I);



M = 3;


R = zeros([size(I,1)*M size(I,2)*M ]);
G = zeros([size(I,1)*M size(I,2)*M ]);
B = zeros([size(I,1)*M size(I,2)*M ]);

K = zeros([size(I,1)*M size(I,2)*M ]);   %boyutlarini M katina cikartiyoruz, hem boyunu hem enini
m = 1;
n = 1;

for i = 1:w                       %aralarini sifir ile doldurdum, 2 katina denk gelecek sekilde
   for j = 1:h
     K(m,n) = I(i,j);
     n = n + M ;
   endfor
   m = m + M ;
   n = 1;
endfor
m = 1;
n = 1;

for i = 1:w                       %aralarini sifir ile doldurdum, 2 katina denk gelecek sekilde
   for j = 1:h
     R(m,n) = I(i,j,1);
     G(m,n) = I(i,j,2);
     B(m,n) = I(i,j,3);
     n = n + M ;
   endfor
   m = m + M ;
   n = 1;
endfor

for i = 1:M:size(K,1)-M
    for j = 1:M:size(K,2)-M
        
            step = (R(i,j+M) .- R(i,j))./M ;        %for divided difference for two consecutive numbers
            R(i,j+M-1) = R(i,j) + step;               %for every color matrix, i calculated new value via divided difference
            R(i+M-1,j) = R(i,j) + step;
            
            step = (G(i,j+M) .- G(i,j))./M ;
            G(i,j+M-1) = G(i,j) + step ;
            G(i+M,j) = G(i,j) + step ;
            
            step = (B(i,j+M) .- B(i,j))./M ;
            B(i,j+M-1) = B(i,j) + step ;
            B(i+M-1,j) = B(i,j) + step ;
        
      for ind_i = i : i+M           %to reach every pixels
          for ind_j = j : j+M
            
           if(R(ind_i,ind_j) == 0 )
              R(ind_i,ind_j) =  R(i,j) + step;
            endif
          if(G(ind_i,ind_j) == 0 )
              G(ind_i,ind_j) =  G(i,j) + step;
          endif
          if(B(ind_i,ind_j) == 0 )
              B(ind_i,ind_j) =  B(i,j) + step;
          endif
             
        endfor
      endfor
        

    end
end

K(:,:,1) = R ;
K(:,:,2) = G ;
K(:,:,3) = B ;
K = uint8(K);
figure,imagesc(K);
%imwrite(K,'C:\\Users\\VOLKAN MAZLUM\\Desktop\\elma.png');   %it is for writing imgae into image

